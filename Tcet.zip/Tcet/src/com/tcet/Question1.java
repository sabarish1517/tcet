package com.tcet;
import java.util.*;
interface Sayable
{
	String say(String name);

}
public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sayable sa=(name)-> name;
		System.out.println(sa.say("hello tns"));

	}

}
