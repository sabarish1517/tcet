package com.tcet;
import java.util.*;
public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>num=Arrays.asList(1,2,3,4,5,6,7);
		List<Integer>evnum=num.stream()
				.filter(num->num%2==0);
		.collect(Collectors.toList());
		System.out.print("even numbers are"+evnum);
		
		

	}

}
