package com.tcet;
import java.util.*;

public class Questin3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine().split("\\s+");
		String k[]=s.toLowerCase();
		Map<String,Integer>wc=new HashMap<>();
		for(String r:k)
		{
			
		}

	}

}
